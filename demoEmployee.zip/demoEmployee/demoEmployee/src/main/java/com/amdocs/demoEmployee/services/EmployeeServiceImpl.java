package com.amdocs.demoEmployee.services;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.demoEmployee.Entity.Employee;
import com.amdocs.demoEmployee.repo.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> fetchAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> allEmployees=employeeRepository.findAll();
		return allEmployees;
	}

	@Override
	public Employee getEmployeeById(Long id) {
		Optional<Employee> employee=employeeRepository.findById(id);
		if(employee.isPresent()) {
			return employee.get();
		}
		return null;
	}

	@Override
	public Employee updateEmployeeById(Long id, Employee employee) {
		Optional<Employee> employee1=employeeRepository.findById(id);
		if(employee1.isPresent()) {
			Employee originalEmployee=employee1.get();
			if(Objects.nonNull(employee.getFirstName()) && !"".equalsIgnoreCase(employee.getFirstName())) {
				originalEmployee.setFirstName(employee.getFirstName());
			}
			if(Objects.nonNull(employee.getLastName()) && !"".equalsIgnoreCase(employee.getLastName())) {
				originalEmployee.setLastName(employee.getLastName());
			}
			if(Objects.nonNull(employee.getEmail()) && !"".equalsIgnoreCase(employee.getEmail())) {
				originalEmployee.setEmail(employee.getEmail());
			}	

		return employeeRepository.save(originalEmployee);
	}

		return null;
}
		
	

	@Override
	public String deleteEmployeeById(Long id) {
		if(employeeRepository.findById(id).isPresent()) {
			employeeRepository.deleteById(id);
			return "Employee successfully deleted";
		}
		return "No such Employee in the database";
	}

}
